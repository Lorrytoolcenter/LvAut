Copyright (c) 2021 lorry_rui
//////////usage://///////////////

VC_tde USE only  @ logitech , Lorry RUi



